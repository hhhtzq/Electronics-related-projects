 #include "mbed.h"
#include "C12832.h" 
#include "sun.h"
#include "snow.h"
#include "axis.h"
#include "rain.h"
Serial pc(USBTX, USBRX); 
PwmOut RED(p23);
PwmOut BLUE(p25);
InterruptIn button(p14);
int x,y;                            //int for axis position
I2C tempsensor(p28, p27);           //sda, sc1
const int addr = 0x90;              //address of tempsensor
char config_t[3];                   //array to configuration tempsensor
char temp_read[2];                  //array to get data from tempsensor
float temp1;                        //floats to bring data in the right format
float temp2;
float i;
float j;
C12832 lcd(p5, p7, p6, p8, p11);    // Initialize lcd
void ISR1() { //this is the response to interrupt, i.e. the ISR
lcd.cls();
            if(temp1<30 and temp1>28){               //set the judgment about the  bitmaps
             lcd.print_bm(bitmsun,48,0);
             lcd.copy_to_lcd();}
            if(temp1<28 and temp1>26){
                lcd.print_bm(bitmrain,48,0);
                lcd.copy_to_lcd();}
            if(temp1< 26){
                lcd.print_bm(bitmsnow,48,0);
                lcd.copy_to_lcd();}
            }
int main()
{
   
    tempsensor.write(addr, config_t, 3);    
    config_t[0] = 0x00;                     //set pointer reg to ’data register’
    tempsensor.write(addr, config_t, 1);    //send to pointer ’read temp'
    while(1) {
         button.rise(&ISR1);
        lcd.cls();
        lcd.print_bm(bitmaxis,24,0);      // print axis in the right part of the lcd
        lcd.copy_to_lcd();
        lcd.locate(12,0);                   //change location of "cursor"
        lcd.printf("30");                   //print there for the scale 30
        lcd.locate(12,12);
        lcd.printf("28");
        lcd.locate(12,24);                  //change location of "cursor"
        lcd.printf("26");                   //print there for the scale 26
        for(x=0; x<100; x++) {                 //for loop to set the whole drawing to a time of 10s
            tempsensor.read(addr, temp_read, 2); //read the two-byte temp data
            temp1 =temp_read[0];                 //make float from the integral part
            temp2 =temp_read[1];                 //make float from the numbers behind decimal dot
            temp1=temp1+(temp2/256);             //combine two part of data
               y=30-((temp1-26)*8);             //calculate y-position on the function
            lcd.pixel((x+24),y,1);           //draw there a pixel
            lcd.copy_to_lcd();
            wait(0.1);                       //wait 100ms --> 100x100ms=10s
            RED.pulsewidth(1); 
            BLUE.pulsewidth(1); 
                if(temp1>30){              //set the judgment about the LED
                  for (i=0;i<1;i=i+0.00001)
                RED = i;}
                 if(temp1<26){
                     for (j=1;j>0;j=j-0.00001)
                BLUE = j;}
        
        }
 pc.printf("Temp = %.2f degC\n\r", temp1);
    }
}
